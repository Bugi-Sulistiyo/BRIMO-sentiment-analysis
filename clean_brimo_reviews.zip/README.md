# Sentiment Analysis of Brimo application
- Bugi Sulistiyo
- bugisulistiyo@gmail.com